# KOMODO-app Flutter
E WASTE management app


![Screenshot_2020-02-14-02-26-43-001_com komododragon komodo](https://user-images.githubusercontent.com/50979611/83979321-25bc3280-a92b-11ea-8b79-f56cb636ed0c.jpg)


![Screenshot_2020-02-16-12-17-12-627_com komododragon innobuzz](https://user-images.githubusercontent.com/50979611/83979308-1341f900-a92b-11ea-865a-469fdac2f7cd.jpg)

# Features to be added
- Refining the UI
- Integrating object detection to the camera
- Strengthing the backend
